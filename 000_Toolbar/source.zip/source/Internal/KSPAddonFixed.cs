﻿using System;

/// <summary>
/// KSPAddon with equality checking using an additional type parameter. Fixes the issue where
/// AddonLoader prevents multiple start-once addons with the same start scene.
/// </summary>
public class KSPAddonFixed : KSPAddon, IEquatable<KSPAddonFixed> {
	private readonly Type type;

	public KSPAddonFixed(KSPAddon.Startup startup, bool once, Type type) : base(startup, once) {
		this.type = type;
	}

	public override bool Equals(object obj) {
		if (obj.GetType() != this.GetType()) {
			return false;
		}
		return Equals((KSPAddonFixed) obj);
	}

	public bool Equals(KSPAddonFixed other) {
		if (this.once != other.once) {
			return false;
		}
		if (this.startup != other.startup) {
			return false;
		}
		if (this.type != other.type) {
			return false;
		}
		return true;
	}

	public override int GetHashCode() {
		return this.startup.GetHashCode() ^ this.once.GetHashCode() ^ this.type.GetHashCode();
	}
}
